<ul class="livestats">
    <li>
        <span class="title">Artifacts<br />Size</span>
        <strong>{!! $artifacts_size !!}</strong>
    </li>
    <li>
        <span class="title">Artifacts<br />Count</span>
        <strong>{!! $artifacts_count !!}</strong>
    </li>
</ul>

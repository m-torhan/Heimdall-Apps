<?php

namespace App\SupportedApps\DokuWiki;

class DokuWiki extends \App\SupportedApps
{
}

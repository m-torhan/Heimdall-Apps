<?php

namespace App\SupportedApps\Concourse;

class Concourse extends \App\SupportedApps
{
}

<?php

namespace App\SupportedApps\Passbolt;

class Passbolt extends \App\SupportedApps
{
}

<?php

namespace App\SupportedApps\MotionEye;

class MotionEye extends \App\SupportedApps
{
}

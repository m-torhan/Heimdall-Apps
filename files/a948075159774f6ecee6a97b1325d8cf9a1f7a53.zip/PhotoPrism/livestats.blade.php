<ul class="livestats">
    <li>
        <span class="title">Photos</span>
        <strong>{!! $photos !!}</strong>
    </li>
    <li>
        <span class="title">Videos</span>
        <strong>{!! $videos !!}</strong>
    </li>
</ul>

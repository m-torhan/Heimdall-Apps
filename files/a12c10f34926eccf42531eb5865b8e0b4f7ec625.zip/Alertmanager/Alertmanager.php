<?php

namespace App\SupportedApps\Alertmanager;

class Alertmanager extends \App\SupportedApps
{
}

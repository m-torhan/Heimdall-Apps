<?php

namespace App\SupportedApps\Mailcow;

class Mailcow extends \App\SupportedApps
{
}

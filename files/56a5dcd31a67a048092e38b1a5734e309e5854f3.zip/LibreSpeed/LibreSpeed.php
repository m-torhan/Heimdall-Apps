<?php

namespace App\SupportedApps\LibreSpeed;

class LibreSpeed extends \App\SupportedApps
{
}
